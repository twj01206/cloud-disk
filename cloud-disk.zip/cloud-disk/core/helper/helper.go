package helper

import (
	"cloud-disk/core/define"
	"crypto/md5"
	"crypto/tls"
	"fmt"
	"net/smtp"

	"github.com/golang-jwt/jwt/v4"
	"github.com/jordan-wright/email"
)

func Md5(s string) string {
	return fmt.Sprintf("%x", md5.Sum([]byte(s)))
}
func GenerateToken(id int, identity, name string) (string, error) {
	uc := define.UserClaim{
		Id:       id,
		Identity: identity,
		Name:     name,
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, uc)
	tokenString, err := token.SignedString([]byte(define.JwtKey))
	if err != nil {
		return "", err
	}
	return tokenString, nil
}

// MailSendCode
// 邮箱验证码发送 发送给谁，发送什么？ 发送后有个error
func MainlSendCode(mail, code string) error {
	e := email.NewEmail()
	e.From = "mihayou <twj01206@163.com>" //发送者
	e.To = []string{"2624095727@qq.com"}  //接收者
	e.Subject = "验证码发送测试"
	e.HTML = []byte("你的验证码为：<h1> + code + </h1>")

	err := e.SendWithTLS("smtp.163.com:465", smtp.PlainAuth("", "twj01206@163.com", "NHJZBKKKDGJVNJYP", "smtp.163.com"),
		&tls.Config{InsecureSkipVerify: true, ServerName: "smtp.163.com"})

	if err != nil {
		return err
	}
	return nil
}
