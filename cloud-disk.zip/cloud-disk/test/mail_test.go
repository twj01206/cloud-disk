package test

import (
	"crypto/tls"
	"net/smtp"
	"testing"

	"github.com/jordan-wright/email"
)

func TestSendMail(t *testing.T) {

	e := email.NewEmail()
	e.From = "Get <twj01206@163.com>"    //发送者
	e.To = []string{"2624095727@qq.com"} //接收者
	e.Subject = "验证码发送测试"
	e.HTML = []byte("你的验证码为：<h1>123456</h1>")

	err := e.SendWithTLS("smtp.163.com:465", smtp.PlainAuth("", "twj01206@163.com", "NHJZBKKKDGJVNJYP", "smtp.163.com"),
		&tls.Config{InsecureSkipVerify: true, ServerName: "smtp.163.com"})

	if err != nil {
		t.Fatal(err)
	}
}
