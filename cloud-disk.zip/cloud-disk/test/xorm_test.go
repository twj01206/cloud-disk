package test

import (
	"bytes"
	"cloud-disk/models"
	"encoding/json"
	"fmt"
	"testing"

	_ "github.com/go-sql-driver/mysql"
	"xorm.io/xorm"
)

func TestXormTest(t *testing.T) {
	engine, err := xorm.NewEngine("mysql", "root:123456@tcp(localhost:3306)/cloud-disk?charset=utf8mb4")
	if err != nil {
		t.Fatal(err)
	}
	data := make([]*models.UserBasic, 0) // 修正类型为 UserBasic
	err = engine.Find(&data)             // 修正为传递 data 的指针
	if err != nil {
		t.Fatal(err)
	}
	fmt.Println(data)            //拿到的是一个struct的地址
	b, err := json.Marshal(data) //数据转换为 JSON 格式
	if err != nil {
		t.Fatal(err)
	}
	dst := new(bytes.Buffer)
	err = json.Indent(dst, b, "", " ")
	if err != nil {
		t.Fatal(err)
	}

	fmt.Println(dst.String())
}
