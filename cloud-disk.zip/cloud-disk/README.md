>轻量级云盘系统，基于go-zero、xorm实现

先是测试数据库的连接：
test-->models
使用到的命令
go get xorm.io/xorm

---------------
go get -u github.com/zeromicro/go-zero@latest
```
goctl api new core # 单体服务
go mod tidy
```
**启动并访问服务**
```
cd core
go run core.go -f etc/core-api.yaml

```
使用api文件生成代码,先进入到core
goctl api go -api core.api -dir . -style go_zero

---
**密码登录**
1. 查询是否存在 (业务逻辑logic)
2. 根据查询结果生成相应的token

**邮箱注册**验证码发送
1. 下载 go get github.com/jordan-wright/email
2. 测试代码：需要开启专用认证服务

```
e := email.NewEmail()
	e.From = "Get <xxx.com>"    //发送者
	e.To = []string{"xxx@qq.com"} //接收者
	e.Subject = "验证码发送测试"
	e.HTML = []byte("你的验证码为：<h1>123456</h1>")

	err := e.SendWithTLS("smtp.163.com:465", smtp.PlainAuth("", "xxx.com", "密码", "smtp.163.com"),
		&tls.Config{InsecureSkipVerify: true, ServerName: "smtp.163.com"})

	if err != nil {
		t.Fatal(err)
	}
```
3. 把测试的代码封装到helper里面
4. 前往logic编写代码
